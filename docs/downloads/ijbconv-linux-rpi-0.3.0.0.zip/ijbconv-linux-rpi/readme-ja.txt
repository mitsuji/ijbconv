==============================
ijbconv (2018/03/26) mitsuji
==============================

IchigoJam BASIC RPi のSDカードの
files ディレクトリ内のSAVEデータを扱うツールです。

ターミナルやコマンドプロンプトなどのシェル用コマンドとして実装しています。
適当な場所に配置し、必要に応じてPATHを通してください。


1. SAVEデータのBASICコードをテキスト表示する

$ ijbconv-exe bt < {バイナリファイル}

# 例
$ ijbconv-exe bt < 100.bin



2. SAVEデータのBASICコードをテキスト形式で保存する

$ ijbconv-exe bt < {バイナリファイル} > {テキストファイル}

# 例
$ ijbconv-exe bt < 100.bin > 100.txt



3. テキスト形式のBASICコードをSAVEデータとして保存する

$ ijbconv-exe tb < {テキストファイル} > {バイナリファイル}

# 例
$ ijbconv-exe tb < 100.txt > 100.bin



ソースコード:
https://github.com/mitsuji/ijbconv


IchigoJam は 株式会社jig.jp の登録商標です。
